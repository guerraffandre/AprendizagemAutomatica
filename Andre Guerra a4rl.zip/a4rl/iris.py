
class Iris:
  id = -1
  sepalLength = 0
  sepalWidth = 0
  petalLength = 0
  petalWidth = 0
  className = ""
  distance = 0
  
  
  
  