
class Position:
  state = 0
  parede = False
  reward = 0.0
  
  
  