from enum import Enum

class Colors(Enum):
    NO_COLOR = -1
    RED = 1
    BLUE = 2
    BROWN = 3
    GREEN = 4
    WHITE = 5
    BLACK = 6
    PURPLE = 7
    ORANGE = 8
    
    
    