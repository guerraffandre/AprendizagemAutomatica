
class Pattern:
    colors = []
    value = 0
    valueInverse = 0