from Colors import Colors

class Position:
  color = Colors.NO_COLOR
  correct = False
  
  
  